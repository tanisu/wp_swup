=== All in One SEO – Powerful SEO Plugin to Boost SEO Rankings & Increase Traffic ===
Contributors: aioseo, smub, benjaminprojas
Tags: SEO, Google Search Console, XML Sitemap, meta description, schema
Tested up to: 6.9
Requires at least: 5.7
Requires PHP: 7.2
Stable tag: 4.9.4.1
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.txt

AIOSEO is the most powerful WordPress SEO plugin. Improve SEO rankings and traffic with comprehensive SEO tools and smart AI SEO optimizations!

== Description ==

### AIOSEO - The Best WordPress SEO Plugin & Toolkit ###

All in One SEO is the original WordPress SEO plugin started in 2007. Today, over 3 million website owners and SEO experts use AIOSEO for higher SEO rankings.

Our users consistently rate [AIOSEO](https://aioseo.com/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin 'All in One SEO for WordPress') as the most comprehensive WordPress SEO plugin and marketing toolkit. It's the fastest way to optimize WordPress SEO settings, add schema markup, create XML sitemap, add local SEO, track SEO keyword rankings, automate internal linking, perform SEO audits, add Author SEO (EEAT), monitor SEO revisions, connect Google search console, and basically everything a SEO Pro would use to rank higher in search engines.

We have AI SEO features that help you optimize your posts for SEO by automatically generating SEO titles, meta descriptions, FAQs, key points, social media posts, and more.

> <strong>AIOSEO Pro</strong><br />
> This is the lite version of the All in One WordPress SEO Pro plugin that comes with all the powerful SEO features you will ever need to rank higher in search engines including **smart SEO schema markup, advanced SEO modules, powerful SEO sitemap suite, local SEO module, SEO keyword ranking tracking, automatic internal linking, WooCommerce SEO**, and tons more. [Click here to purchase the best premium WordPress SEO plugin now!](https://aioseo.com/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin 'All in One SEO for WordPress')

Here's why smart business owners, SEO experts, marketers, and developers love AIOSEO, and you will too!

[youtube https://youtu.be/UbOYEEIvXvY]

### What Makes AIOSEO Better than Other WordPress SEO Plugins ###

AIOSEO is leading the innovation in WordPress SEO space, and our SEO features will give you a competitive advantage.

* **Easy SEO Setup Wizard**
Our SEO setup wizard optimizes your website's SEO settings based on your unique industry needs in less than 5 minutes.

* **Smart Schema Markup (aka Rich Snippets)**
Get better click through rate (CTR) and Google rich featured snippets using advanced SEO schema markups like FAQ schema, product schema, recipe schema markup, and dozens more using our custom [Schema Generator](https://aioseo.com/features/rich-snippets-schema/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin 'Schema Generator').

* **AI Content**
Create anything you need, such as blog articles and tables, with our AI Assistant block. Generate stunning visuals instantly with the built-in AI Image Generator. Save time by automatically generating SEO titles, meta descriptions, FAQs, key points, social media posts, and more with our [AI Content Generator](https://aioseo.com/features/ai-content/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin 'AI Content').

* **Unlimited SEO Keywords**
Optimize for unlimited SEO keywords using our SEO content analyzer. Our TruSEO score gives you detailed content & readability analysis, so you can get higher SEO rankings.

* **Google Keyword Rank Tracking**
Easily track how your website is ranking for different keywords in Google from your [WordPress dashboard](https://aioseo.com/features/search-statistics/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin 'Google Keyword Rank Tracker').

* **Automatic Link Assistant**
Automate internal links between your pages using our smart [internal linking algorithm](https://aioseo.com/features/internal-link-assistant/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin 'Link Assistant') that will help improve on-page SEO.

* **Local Business SEO**
Improve your local SEO presence with local business schema, support for multiple local store locations, business opening hours, Google Maps integration, contact info (business email, business phone, business address, etc), and more with our [Local SEO module](https://aioseo.com/features/local-seo/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin 'Local SEO').

* **Site Audit**
Get a detailed report of SEO issues for all posts and terms on your site, discover why these issues are important and how you can fix them.

* **SEO Revisions**
Keep a [historical record of SEO changes](https://aioseo.com/seo-revisions/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin 'SEO Revisions'), monitor the impact of changes, and restore previous versions in one click.

* **Content Decay Tracking**
Never lose traffic to competitors. Quickly detect which content is losing traffic / SEO rankings, so you can optimize it to regain your rankings with our [Search Statistics module](https://aioseo.com/features/search-statistics/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin 'Search Statistics').

* **Smart XML Sitemap**
Advanced XML sitemaps to boost your SEO rankings (with easy setup inside Google Search Console). Also includes Video SEO XML sitemap, News SEO XML sitemap, RSS sitemap, and HTML sitemap.

* **404 Error Monitor**
Automatic 404 error monitor helps you track and redirect 404 errors, so you don't lose SEO rankings.

* **Author SEO**
Add [custom author profile pages, author bio box, and relevant author schema](https://aioseo.com/features/author-seo-google-e-e-a-t/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin 'Author SEO (E-E-A-T)') to boost Google EEAT score to help with Google's Helpful Content Update (HCU).

* **LLMs.txt Generator**
Generate an llms.txt file to help AI engines discover your site's content more easily so your content can rank in AI search results.

* **SEO Audit Checklist**
Improve your SEO ranking with our comprehensive SEO audit checklist.

* **Knowledge Graph Support**
Improve your website's search appearance with SEO Knowledge panel.

* **Table of Contents**
Automatically generate a table of content, customize headings, anchors, and you can also hide or reorder the headings.

### Advanced SEO Plugin Features ###

* **User Access Control**
Control who can manage your SEO settings with our advanced SEO access control.

* **WordPress REST API**
Manage your SEO metadata with WordPress REST API. Great for headless WordPress installations.

* **Advanced Robots Meta SEO Settings**
Granular controls for no index, no follow, no archive, no snippet, max snippet, max video, etc.

* **RSS Content for SEO**
Stop content scraping from hurting your SEO rankings.

* **Full Site Redirects**
Merging websites or switching domains? Full site redirect makes it easy to switch domains without losing SEO rankings.

* **Smart Meta Title & Description**
Automatic SEO generation, dynamic SEO smart tags, include Emoji, add shortcodes, and more features to stand out in search results.

* **Smart Breadcrumbs**
Add Breadcrumb navigation to improve user experience and boost your SEO rankings. Comes with full SEO JSON+LD support.

* **Automatic Image SEO**
Helps your images rank higher by autogenerating image title, clean SEO image filenames, and more.

* **Advanced SEO Canonical URLs**
Prevent duplicate content in SEO with automatic canonical URLs.

* **SEO Cleanup / Manual SEO Penalty Removal**
Domains Report feature in Link Assistant automatically removes all links for specific domains with just one click. Huge time saver when doing SEO cleanups.

* **Link Opportunities Report**
See better internal link opportunities with our smart algorithm. Easily add internal links with just a few clicks.

* **Robots.txt Editor**
Manage and customize SEO robots.txt files in WordPress.

* **Crawl Quota Management**
Crawl Cleanup feature manages your search engine crawl quota and index your important content faster.

* **Title and Nofollow for SEO**
Easily add title and nofollow to external links.

* **Headline Analyzer**
Analyze your page / posts headlines to improve CTR and SEO rankings.

* **Competitor Site SEO Analysis**
Use competitor SEO analysis to outrank them with better SEO optimization.

* **SEO Code Snippets**
Integration with [WPCode plugin](https://wordpress.org/plugins/insert-headers-and-footers/) for SEO code snippets to further customize every aspect of your SEO.


### WordPress SEO Integrations ###

* **Google Search Console Integration**
Connect with Google webmaster tools and Google Search Console to see SEO insights (like content rankings, keyword rankings, page speed insights, post index status, etc) directly in your WordPress dashboard.

* **WooCommerce SEO**
Improves your WooCommerce SEO rankings. Easily optimize WooCommerce product pages, product categories, and more for best eCommerce SEO results.

* **Knowledge Panel SEO**
Improve website SEO appearance by adding social media profile links for Facebook, Twitter, Wikipedia, Instagram, LinkedIn, Yelp, YouTube, and more.

* **Webmaster Tool Integrations**
Connect with all webmaster tools including Google Search Console, Bing SEO, Yandex SEO, Baidu SEO, Google Analytics, Pinterest site verification, and more.

* **Social Media Integration**
Facebook SEO, Twitter SEO, and Pinterest SEO with better website previews.

* **Google AMP SEO Integration**
Improve your mobile SEO rankings with Google AMP SEO.

* **Semrush SEO integration**
See additional SEO keywords with Semrush SEO integration.

* **Microsoft Clarity Integration**
See visitor interactions with heatmaps and session recordings.

* **IndexNow Integration**
Instantly notify Bing and Yandex for faster SEO indexing.

* **Elementor SEO**
Better Elementor SEO for landing pages.

* **Divi SEO**
Better Divi SEO for landing pages.

* **Avada SEO**
Better Avada SEO for landing pages.

* **WP Bakery SEO**
Better WP Bakery SEO for landing pages.

* **SeedProd SEO**
Optimize SeedProd landing pages for SEO.

* **SiteOrigin SEO**
Better SiteOrigin SEO for landing pages.

* **Open Graph Support**
Improve SEO rankings with open graph meta data.

### WordPress SEO Plugin Importer ###

Not happy with your current SEO plugin? We make SEO migration easy with our point-and-click automated SEO data transfer tool. We currently support SEO migration from following SEO tools:

* Yoast SEO Importer
* Yoast SEO Premium Importer
* RankMath SEO Importer
* SEOPress

We also support importing SEO redirects from the following plugins:

* Redirection Plugin
* Simple 301 Redirects Importer
* Safe Redirect Manager
* 301 Redirects Importer

Aside from that, our SEO migration tool also helps you with:

* Import / Export AIOSEO settings from one site to another
* Create SEO Settings Backup
* CSV Sitemap Import to Import additional pages to your XML Sitemaps


**Now you can see why AIOSEO is often rated the best SEO plugin in WordPress.**

Give AIOSEO a try.

Want to unlock more SEO features? [Upgrade to AIOSEO Pro](https://aioseo.com/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin 'All in One SEO for WordPress').

### Credits ###

This plugin is created by [Benjamin Rojas](https://benjaminrojas.net/ 'Benjamin Rojas') and [Syed Balkhi](https://syedbalkhi.com/ 'Syed Balkhi').

### Branding Guideline ###

AIOSEO&reg; is a registered trademark of Semper Plugins LLC. When writing about the WordPress SEO plugin by AIOSEO, please use the following format.

* AIOSEO (correct)
* All in One SEO (correct)
* AIO SEO (incorrect)
* All in 1 SEO (incorrect)
* AISEO (incorrect)

== Changelog ==

**New in Version 4.9.4.1**

* Fixed: Smart tags sometimes not inserting into attached text area.

**New in Version 4.9.4**

* New: SEO Checklist - Our new checklist helps you get your site's SEO properly configured, with prioritized tasks that automatically complete as you configure settings and fix issues.
* Updated: Menu pages and many other libraries are now lazy-loaded, significantly reducing the initial page load time.
* Fixed: PHP warning in SEO Analyzer when URL does not have a valid path.

**New in Version 4.9.3**

* Updated: Added a new filter to disable the AI Assistant block and extensions.
* Updated: Added new filters to customize the LLMs title and description.
* Updated: Added review support to Book and Event schema types for rich search results.
* Updated: Hardened API routes to prevent AI access token from being exposed.
* Updated: Removed the "New feature" alert for Keyword Rank Tracker.
* Updated: Incorrect link in the Add Focus Keyword button of Site Audit.
* Updated: Refactored WPBakery page builder integration for improved maintainability.
* Updated: Table of Contents script now only loads if the TOC block is present on the page.
* Updated: Added input sanitization for editable fields in the post details column.
* Fixed: Console errors when trying to edit a template with Site Editor.
* Fixed: Duplicate entries in the Search Statistics objects table caused by inconsistent path hashing.
* Fixed: Improved sitemap generation for custom post types and custom taxonomies.
* Fixed: Javascript TypeError when expanding certain Site Audit issue rows in SEO Analysis.
* Fixed: AI Image Generator now correctly detects aspect ratio when editing portrait or square images.
* Fixed: Console errors that occurred when users without proper permissions attempted to publish or update posts.
* Fixed: PHP fatal error when accessing sitemaps for Custom Post Types with slugs matching internal method names.
* Fixed: SEO plugin imports (Yoast, Rank Math, SEOPress) now only process posts and terms with existing data, improving performance and preventing unnecessary database growth.

**New in Version 4.9.2**

* New: Page Builder Integrations for Bricks & Oxygen - You can now seamlessly control your SEO settings directly within the visual builders of Bricks and Oxygen and analyze their content with TruSEO.
* Fixed: Browser alert incorrectly appearing in Classic Editor after page reload when Focus Keyword is set.

**New in Version 4.9.1.1**

* New: Users using AIOSEO, Broken Link Checker and Link Assistant now see their broken links count in the AIOSEO Details post column.
* Updated: Compatibility with WordPress 6.9.
* Updated: Various database performance improvements.
* Updated: Hardened database queries against SQL attacks.
* Fixed: Redirects would no longer work for AIOSEO Pro users on discontinued plans.
* Fixed: AI Assistant shortcut no longer shown for paragraph blocks that are nested under a parent block.

**New in Version 4.9.1**

* New: AI Insights - Our new AI-powered Keyword Report tool lets you see which brands are ranking for search queries in AI search results. Now 100% free for a limited time only!
* New: Basic & Plus plan AIOSEO Pro users can now create redirects and control HTTP headers!
* Updated: Switched from PHP serialization to JSON for caching to prevent cache misses due to charset mismatches.
* Updated: Translations are no longer fetched when the site and all users are using the English locale.
* Updated: Latest available date for Google Search Console data is now fetched in the background.
* Updated: Improved error handling and performance for Semrush integration.
* Updated: Added a filter to customize the Site Audit scan interval.
* Updated: Added new shortcuts to the AI Assistant block to tweak content length, structure and tone.
* Updated: Improved HTML parsing for Site Audit.
* Fixed: Smart tag names now correctly refer to the current post type.
* Fixed: Some multisite network admins were unable to analyze competitor URLs in SEO Analysis.
* Fixed: Browser "unsaved changes" alert now properly triggers when SEO settings are modified in post editor.
* Fixed: Styling for breadcrumb separator settings in Thrive Architect page builder.
* Fixed: Incorrect character count calculation for the Product Short Description smart tag.
* Fixed: PHP warnings triggered when Search Statistics processed incomplete or malformed data from Google Search Console.
* Fixed: Conflict with the Pro Mail SMTP plugin causing some AIOSEO fields to be inaccessible.
* Fixed: TruSEO was not detecting links present in the FAQ Block.
* Fixed: Video sitemap scan now properly handles numeric post IDs when triggered by WP Cron, preventing posts from being skipped during automated scans.
* Fixed: PHP warning shown on the custom login page of Theme My Login plugin when AIOSEO was active.
* Fixed: Scheduled actions for clearing redirect logs failing due to unregistered callbacks.
* Fixed: Some users not being able to access Redirect menu in Lite.

**New in Version 4.9.0**

* New: Table of Contents Block 2.0 - Our revamped Table of Contents block now supports multiple blocks on the same page, with a standalone or synced mode. We also added accordion support so you can collapse or expand it.
* New: Recipe Block - Highlight your best recipes with a new block that also comes with schema markup to get your recipes featured in search results.
* New: Products Block - Showcase your products with granular controls and Product schema markup to drive more organic traffic to your page.
* Fixed: Rare PHP error when action scheduler arguments are not a JSON object.
* Fixed: DB lock issue when checking table schema in MariaDB.

**New in Version 4.8.9**

* Updated: Improved user permission checks to display Site Audit action buttons.
* Updated: Added filter to disable AI Image Generator buttons in the block editor.
* Fixed: Conflict with Avada theme where post content was disappearing in backend editor.
* Fixed: Elementor Side Cart automatically opening even when the cart is empty on single product pages.
* Fixed: Category title missing from meta descriptions on new sites.
* Fixed: Redundant schema queries when database schema cache fails to update.
* Fixed: JS error when accessing string offsets in SEO revisions data processing.
* Fixed: Keyword Rank Tracker button broke in the Post editor if the Spectra or Starter Templates plugin was activated.
* Fixed: Homepage meta description character counter breaks when the site is set as an Organization.
* Fixed: New feature popups rendering outside the viewport on smaller screens.

**New in Version 4.8.8**

* New: AI Assistant Block - Generate any type of content right inside the post editor: blog articles, summaries, comparison tables, and more. Whatever you need, the AI Assistant block makes it happen.
* New: AI Image Generator - Instantly create eye-catching visuals for your posts and use them anywhere—from featured images to inline content. You can even edit existing images to give them a unique twist.
* New: LLMs.txt Improvements – The new llms-full.txt file makes it easy for AI engines to index your site without overloading your server. We’ve also added post-to-Markdown conversion and new settings to control exactly what content gets included.
* Updated: All existing AI Content features have been made compatible with all our supported page builders. You can now auto-generate SEO titles, meta descriptions, FAQs, keypoints and social posts directly inside Elementor, Divi, SeedProd, Avada, WPBakery, SiteOrigin and Thrive Architect!
* Updated: The llms.txt file is now generated as a static file, removing the need for rewrite rules (e.g. on WP Engine).
* Updated: Moved llms.txt under Sitemaps menu.
* Fixed: Site Audit sometimes not showing results when all content types are included.
* Fixed: PHP error when Site Audit cannot scan post due to uninstantiated social class.
* Fixed: PHP error when dashboard widget failed to fetch RSS news feed.

**See our [changelog on aioseo.com](https://aioseo.com/changelog/?utm_source=wprepo&utm_medium=link&utm_campaign=aioseo) for previous releases.**

== Frequently Asked Questions ==

Please visit our [complete AIOSEO documentation](https://aioseo.com/docs/?utm_source=wprepo&utm_medium=link&utm_campaign=liteplugin) before requesting support for SEO from the AIOSEO team.

= Who should use AIOSEO? =

SEO is essential for all websites. AIOSEO is perfect for business owners, bloggers, marketers, designers, developers, photographers, and basically everyone else. If you want to rank higher in search, then you need to use AIOSEO WordPress SEO plugin.

= Which themes does AIOSEO support? =

AIOSEO works with all WordPress themes. Simply enable AIOSEO to make your WordPress theme SEO friendly.

= Will AIOSEO slow down my website? =

Nope, AIOSEO will NOT slow down your website. We understand that speed is important for SEO, that's why our code is properly optimized for maximum performance. Remember, faster websites rank higher in search. Use AIOSEO for fast SEO improvements.

= Can I use AIOSEO on client sites? =

Yes, you can use AIOSEO on client websites.

= Are AIOSEO sitemaps better than default WordPress sitemaps? =

Yes, AIOSEO smart sitemaps are a lot more optimized than the default WordPress sitemaps. Once you enable AIOSEO, our XML sitemaps will override the default WordPress sitemaps, so you can improve your SEO rankings.

We also offer advanced SEO sitemaps such as News Sitemap, Video Sitemap, and RSS Sitemap.

Our SEO sitemaps come with granular control such as links per sitemap, enable / disable post types or taxonomies, include / exclude specific links from sitemap, add additional non-WordPress pages to sitemaps, customize sitemap priority & frequency for each section of your site, and more.

This is why experts rate AIOSEO as the best WordPress SEO plugin.

= Does AIOSEO help with SEO Verification? =

Yes. AIOSEO can help you with website SEO verification with various webmaster tools such as Google Search Console, Bing Webmaster Tools, Yandex, Baidu, Pinterest, and just about every other site verification you need.

= Why is AIOSEO better than other SEO plugins? =

There are many WordPress SEO plugins out there. Unlike others, AIOSEO WordPress SEO plugin is always reliable. Our SEO features are results focused (no bloat), and we offer exceptional customer support.

AIOSEO is the original WordPress SEO plugin, and it's trusted by over 3 million website owners.

= Do I really need an XML Sitemap? =

**Yes! XML Sitemaps help Google and other search engines to find all the pages of your website.**

An XML sitemap is a list of all the content on your website. The sitemap helps search engine bots to easily see all the content on your site in one place, The XML sitemap file is hidden from your human visitors, however search engines like Google can see it.

Without an XML sitemap, some of your web pages may never be included in Google search results, and won't get any traffic.

XML Sitemaps also help you tell Google which pages you DON'T want included in search results. This can help your SEO to prevent keyword cannibalization and duplicate content issues.

As part of your SEO strategy, **an XML sitemap can help you to improve your domain authority and unlock more traffic from Google, Bing and other search engines**.

AIOSEO can easily help you get your sitemaps listed inside Google Search Console so your content can start to get indexed today!

= Does AIOSEO integrate directly with Google Search Console? =

Absolutely! Our integration with Google Search Console allows you to monitor and maintain your website's presence on Google. With our direct integration, you can easily view important information about your website, such as the number of clicks, impressions, and the average position for each keyword that your website's content appears for in Google search results. You can also track your contents page speed using Google's Page Speed Insights directly inside your WordPress dashboard.

Additionally, AIOSEO can also provide you with data on the most frequently used keywords, the most popular pages on your website, and any crawl errors or security issues that may arise. By integrating with Google Search Console, AIOSEO provides website owners with valuable insights that can help to improve SEO and overall online visibility. With this integration, you can track your site's progress over time and make data-driven decisions that will help you achieve your SEO goals.

== Screenshots ==

1. SEO Content Analyzer (Gutenberg)
2. SEO Content Analyzer (Classic Editor)
3. SEO Setup Wizard
4. SEO Site Analysis
5. Webmaster Tools Connect
6. Social Media Integrations
7. Local SEO
8. Sitemaps
9. Search Appearance Settings
10. Robots.txt Editor
11. RSS Content Control
12. Headline Analyzer
13. Redirect Manager
14. Link Assistant

== Upgrade Notice ==

= 4.9.4.1 =

This update adds major improvements and bug fixes.